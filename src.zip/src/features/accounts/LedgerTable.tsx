'use client';

import React, { useState, useMemo } from 'react';
import { 
  Download, Search, Filter, Calendar, ChevronLeft, ChevronRight, 
  BarChart3, FileText, CheckCircle2, AlertCircle, Clock
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { EmptyState } from '@/components/ui/empty-state';

export type LedgerType = 'income' | 'expense';

export interface LedgerItem {
  id: string;
  date: string;
  project_id?: string;
  project_name: string;
  category: string;
  description: string;
  amount: number;
  status: string;
  added_by?: string;
  receipt_url?: string;
  source: 'invoice' | 'payment' | 'expense';
}

interface LedgerTableProps {
  data: LedgerItem[];
  type: LedgerType;
  projects: { id: string; name: string }[];
}

export function LedgerTable({ data, type, projects }: LedgerTableProps) {
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [projectFilter, setProjectFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [isExporting, setIsExporting] = useState(false);
  const itemsPerPage = 15;

  const categories = useMemo(() => {
    const cats = new Set<string>();
    data.forEach(item => cats.add(item.category));
    return Array.from(cats).sort();
  }, [data]);

  const filteredData = useMemo(() => {
    let result = data;
    
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(item => 
        item.description.toLowerCase().includes(q) || 
        item.project_name.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
      );
    }
    
    if (categoryFilter) {
      result = result.filter(item => item.category === categoryFilter);
    }
    
    if (projectFilter) {
      if (projectFilter === 'company-wide') {
        result = result.filter(item => !item.project_id || item.project_id === 'company-wide');
      } else {
        result = result.filter(item => item.project_id === projectFilter);
      }
    }
    
    if (dateFrom) {
      const fromDate = new Date(dateFrom).getTime();
      result = result.filter(item => new Date(item.date).getTime() >= fromDate);
    }
    
    if (dateTo) {
      // Add one day to include the end date fully
      const toDate = new Date(dateTo);
      toDate.setHours(23, 59, 59, 999);
      result = result.filter(item => new Date(item.date).getTime() <= toDate.getTime());
    }
    
    // Sort descending by date
    return result.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [data, search, categoryFilter, projectFilter, dateFrom, dateTo]);

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const paginatedData = filteredData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleExportCSV = () => {
    setIsExporting(true);
    try {
      const headers = type === 'income' 
        ? ['Date', 'Project', 'Description', 'Category', 'Amount', 'Status']
        : ['Date', 'Project', 'Category', 'Description', 'Amount', 'Added By'];
        
      const rows = filteredData.map(item => {
        if (type === 'income') {
          return [
            format(new Date(item.date), 'yyyy-MM-dd'),
            `"${item.project_name.replace(/"/g, '""')}"`,
            `"${item.description.replace(/"/g, '""')}"`,
            `"${item.category}"`,
            item.amount.toString(),
            `"${item.status}"`
          ];
        } else {
          return [
            format(new Date(item.date), 'yyyy-MM-dd'),
            `"${item.project_name.replace(/"/g, '""')}"`,
            `"${item.category}"`,
            `"${item.description.replace(/"/g, '""')}"`,
            item.amount.toString(),
            `"${(item.added_by || '').replace(/"/g, '""')}"`
          ];
        }
      });
      
      const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${type}_ledger_export_${format(new Date(), 'yyyy-MM-dd')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error('Export failed', e);
    } finally {
      setIsExporting(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const s = status.toLowerCase();
    if (s === 'paid' || s === 'approved' || s === 'verified') {
      return <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20"><CheckCircle2 className="w-3 h-3" /> {status}</span>;
    }
    if (s === 'pending' || s === 'sent') {
      return <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400 border border-amber-200 dark:border-amber-500/20"><Clock className="w-3 h-3" /> {status}</span>;
    }
    return <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-slate-50 text-slate-600 dark:bg-slate-500/10 dark:text-slate-400 border border-slate-200 dark:border-slate-500/20">{status}</span>;
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);
  };

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <div className="flex flex-col xl:flex-row items-center gap-4 bg-white dark:bg-white/[0.02] p-4 rounded-2xl border border-slate-200/60 dark:border-white/10 shadow-sm">
        <div className="relative w-full xl:w-64 shrink-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
            placeholder="Search descriptions..."
            className="w-full pl-9 pr-4 h-10 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all dark:text-white placeholder:text-slate-400"
          />
        </div>
        
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-4 w-full">
          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => { setDateFrom(e.target.value); setCurrentPage(1); }}
              className="w-full h-10 px-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all dark:text-white"
            />
            <span className="text-slate-400 text-sm">to</span>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => { setDateTo(e.target.value); setCurrentPage(1); }}
              className="w-full h-10 px-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all dark:text-white"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => { setCategoryFilter(e.target.value); setCurrentPage(1); }}
            className="h-10 px-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all dark:text-white appearance-none cursor-pointer w-full sm:w-32 shrink-0"
          >
            <option value="">All Categories</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>

          <select
            value={projectFilter}
            onChange={(e) => { setProjectFilter(e.target.value); setCurrentPage(1); }}
            className="h-10 px-3 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all dark:text-white appearance-none cursor-pointer w-full sm:w-48 shrink-0"
          >
            <option value="">All Projects</option>
            <option value="company-wide">Company-wide</option>
            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>

          <button
            onClick={handleExportCSV}
            disabled={isExporting || filteredData.length === 0}
            className="h-10 px-4 shrink-0 bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-sm font-semibold transition-all flex items-center gap-2 shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">{isExporting ? 'Exporting...' : 'Export CSV'}</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-white/[0.02] border border-slate-200/60 dark:border-white/10 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 dark:bg-white/[0.02] border-b border-slate-200/60 dark:border-white/5">
                <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Date</th>
                <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Project</th>
                {type === 'income' ? (
                  <>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Description</th>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Category</th>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap text-right">Amount</th>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Status</th>
                  </>
                ) : (
                  <>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Category</th>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Description</th>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap text-right">Amount</th>
                    <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Added By</th>
                  </>
                )}
                <th className="py-4 px-6 text-xs font-black uppercase tracking-widest text-slate-400 whitespace-nowrap">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedData.length === 0 ? (
                <tr>
                  <td colSpan={type === 'income' ? 7 : 7} className="py-20 text-center">
                    <EmptyState 
                      icon={BarChart3} 
                      message="No records found for the given filters." 
                    />
                  </td>
                </tr>
              ) : (
                paginatedData.map((item, idx) => (
                  <tr 
                    key={`${item.id}-${idx}`} 
                    className="border-b border-slate-100 dark:border-white/5 hover:bg-slate-50/50 dark:hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="py-4 px-6 text-sm text-slate-500 dark:text-slate-400 whitespace-nowrap font-medium">
                      {format(new Date(item.date), 'MMM d, yyyy')}
                    </td>
                    <td className="py-4 px-6">
                      <span className="inline-flex items-center px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-300">
                        {item.project_name}
                      </span>
                    </td>
                    
                    {type === 'income' ? (
                      <>
                        <td className="py-4 px-6 text-sm text-slate-900 dark:text-white max-w-[250px] truncate">
                          {item.description}
                        </td>
                        <td className="py-4 px-6 text-sm text-slate-500 dark:text-slate-400 capitalize">
                          {item.category}
                        </td>
                        <td className="py-4 px-6 text-sm font-semibold tabular-nums text-right text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                          {formatAmount(item.amount)}
                        </td>
                        <td className="py-4 px-6">
                          {getStatusBadge(item.status)}
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="py-4 px-6 text-sm text-slate-500 dark:text-slate-400 capitalize whitespace-nowrap">
                          {item.category}
                        </td>
                        <td className="py-4 px-6 text-sm text-slate-900 dark:text-white max-w-[250px] truncate">
                          {item.description}
                        </td>
                        <td className="py-4 px-6 text-sm font-semibold tabular-nums text-right text-rose-600 dark:text-rose-400 whitespace-nowrap">
                          {formatAmount(item.amount)}
                        </td>
                        <td className="py-4 px-6 text-sm text-slate-500 dark:text-slate-400 whitespace-nowrap">
                          {item.added_by || '-'}
                        </td>
                      </>
                    )}
                    
                    <td className="py-4 px-6 whitespace-nowrap">
                      {item.receipt_url ? (
                        <a 
                          href={item.receipt_url} 
                          target="_blank" 
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition-colors"
                        >
                          <FileText className="w-3.5 h-3.5" /> View
                        </a>
                      ) : (
                        <span className="text-xs text-slate-400 dark:text-slate-500 px-3">-</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-6 py-4 border-t border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-[#0a0d16] flex items-center justify-between">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Showing <span className="font-semibold text-slate-900 dark:text-white">{(currentPage - 1) * itemsPerPage + 1}</span> to <span className="font-semibold text-slate-900 dark:text-white">{Math.min(currentPage * itemsPerPage, filteredData.length)}</span> of <span className="font-semibold text-slate-900 dark:text-white">{filteredData.length}</span> results
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="w-8 h-8 rounded-lg flex items-center justify-center border border-slate-200 dark:border-white/10 text-slate-500 disabled:opacity-50 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="w-8 h-8 rounded-lg flex items-center justify-center border border-slate-200 dark:border-white/10 text-slate-500 disabled:opacity-50 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
