'use client';

import React from 'react';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { BarChart3 } from 'lucide-react';

export type ChartType = 
  | 'income-vs-expense' 
  | 'revenue-trend' 
  | 'expense-categories' 
  | 'cash-flow' 
  | 'profit-trend' 
  | 'project-profitability';

interface FinanceChartProps {
  title: string;
  subtitle?: string;
  type: ChartType;
  data: any[];
  loading?: boolean;
}

// Colors mapped to Tailwind tokens
const COLORS = {
  emerald: '#10b981',
  rose: '#f43f5e',
  indigo: '#6366f1',
  amber: '#f59e0b',
  sky: '#0ea5e9',
  slate: '#64748b'
};

const PIE_COLORS = [COLORS.indigo, COLORS.sky, COLORS.amber, COLORS.emerald, COLORS.rose, COLORS.slate];

const formatCurrency = (value: number) => {
  if (value >= 100000) return `₹${(value / 100000).toFixed(1)}L`;
  if (value >= 1000) return `₹${(value / 1000).toFixed(1)}k`;
  return `₹${value}`;
};

export function FinanceChart({ title, subtitle, type, data, loading }: FinanceChartProps) {
  
  const hasData = data && data.length > 0 && !data.every(d => 
    Object.values(d).every(val => typeof val !== 'number' || val === 0)
  );

  return (
    <div className="bg-white dark:bg-white/[0.02] border border-slate-200/60 dark:border-white/10 rounded-2xl p-5 shadow-sm flex flex-col">
      <div className="mb-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">{title}</h3>
        {subtitle && <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitle}</p>}
      </div>

      <div className="flex-1 w-full h-[300px] relative">
        {loading ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-full h-full animate-pulse bg-slate-100 dark:bg-white/5 rounded-xl"></div>
          </div>
        ) : !hasData ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <BarChart3 className="w-8 h-8 text-slate-300 dark:text-slate-600 mb-2" />
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Not enough data yet</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            {renderChart(type, data)}
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}

function renderChart(type: ChartType, data: any[]) {
  const commonAxisProps = {
    stroke: '#94a3b8',
    fontSize: 12,
    tickLine: false,
    axisLine: false
  };

  switch (type) {
    case 'income-vs-expense':
      return (
        <BarChart data={data} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-white/10" />
          <XAxis dataKey="month" {...commonAxisProps} />
          <YAxis tickFormatter={formatCurrency} {...commonAxisProps} />
          <Tooltip 
            cursor={{ fill: 'transparent' }} 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            formatter={(value: any) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value)}
          />
          <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
          <Bar dataKey="income" name="Income" fill={COLORS.emerald} radius={[4, 4, 0, 0]} />
          <Bar dataKey="expense" name="Expense" fill={COLORS.rose} radius={[4, 4, 0, 0]} />
        </BarChart>
      );
      
    case 'revenue-trend':
      return (
        <LineChart data={data} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-white/10" />
          <XAxis dataKey="month" {...commonAxisProps} />
          <YAxis tickFormatter={formatCurrency} {...commonAxisProps} />
          <Tooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            formatter={(value: any) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value)}
          />
          <Line type="monotone" dataKey="income" name="Revenue" stroke={COLORS.indigo} strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
        </LineChart>
      );

    case 'cash-flow':
      const cashFlowData = data.map(d => ({ ...d, net: d.income - d.expense }));
      return (
        <LineChart data={cashFlowData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-white/10" />
          <XAxis dataKey="month" {...commonAxisProps} />
          <YAxis tickFormatter={formatCurrency} {...commonAxisProps} />
          <Tooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            formatter={(value: any) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value)}
          />
          <Line type="monotone" dataKey="net" name="Net Cash Flow" stroke={COLORS.sky} strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
        </LineChart>
      );

    case 'profit-trend':
      const profitData = data.map(d => ({ ...d, profit: d.income - d.expense }));
      return (
        <LineChart data={profitData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-white/10" />
          <XAxis dataKey="month" {...commonAxisProps} />
          <YAxis tickFormatter={formatCurrency} {...commonAxisProps} />
          <Tooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            formatter={(value: any) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value)}
          />
          <Line type="monotone" dataKey="profit" name="Profit" stroke={COLORS.emerald} strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
        </LineChart>
      );

    case 'project-profitability':
      return (
        <BarChart data={data.slice(0, 10)} margin={{ top: 10, right: 10, left: 10, bottom: 0 }} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" className="dark:stroke-white/10" />
          <XAxis type="number" tickFormatter={formatCurrency} {...commonAxisProps} />
          <YAxis dataKey="name" type="category" width={100} tickFormatter={(val: string) => val.length > 12 ? val.substring(0, 12) + '...' : val} {...commonAxisProps} />
          <Tooltip 
            cursor={{ fill: 'transparent' }} 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            formatter={(value: any) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value)}
          />
          <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
          <Bar dataKey="invoiced" name="Invoiced" fill={COLORS.sky} radius={[0, 4, 4, 0]} />
          <Bar dataKey="expenses" name="Expenses" fill={COLORS.rose} radius={[0, 4, 4, 0]} />
          <Bar dataKey="margin" name="Margin" fill={COLORS.emerald} radius={[0, 4, 4, 0]} />
        </BarChart>
      );

    case 'expense-categories':
      return (
        <PieChart margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
          <Tooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            formatter={(value: any) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value)}
          />
          <Legend wrapperStyle={{ fontSize: '12px' }} />
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={2}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
            ))}
          </Pie>
        </PieChart>
      );

    default:
      return null;
  }
}
