import React from "react";
import { getUserProfileAction } from "@/actions/auth.actions";
import { getMyAssignedProjectsAction, getUnassignedQueueAction, getCADMetricsAction } from "@/actions/operations.actions";
import { getSOPsAction } from "@/actions/sop.actions";
import { getMyEODReportsAction } from "@/actions/eod.actions";
import {
  PenTool, ChevronRight, AlertTriangle, CheckCircle2,
  Clock, FileText, Zap, Upload, Eye, ListPlus, TrendingUp, Layers, CheckCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { SOPList } from "@/components/sop/SOPList";
import DashboardNotificationCenter from "@/components/modules/DashboardNotificationCenter";
import { PendingProjectListCard } from "@/components/modules/PaginatedProjectList";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyState } from "@/components/ui/empty-state";
import { formatDistanceToNow, format, differenceInHours } from "date-fns";

export default async function CADDashboardPage() {
  const profile = await getUserProfileAction();
  const firstName = profile?.first_name || "CAD Specialist";

  const [assignedRes, unassignedRes, sopsRes, eodRes, metricsRes] = await Promise.all([
    getMyAssignedProjectsAction(),
    getUnassignedQueueAction("cad"),
    getSOPsAction(),
    getMyEODReportsAction(),
    getCADMetricsAction(),
  ]);

  const projects = (assignedRes.data || []).filter(
    (p: any) => !["completed", "archived"].includes(p.status)
  );

  const unassignedProjects = unassignedRes.data || [];

  const sops = sopsRes.data || [];
  const eodReports = eodRes.success ? eodRes.data : [];

  const metricsData = metricsRes.data || { projectDrawingCounts: {}, activeRevisions: [], productivity: { weeklyHours: 0, weeklyTasksCompleted: 0 } };

  const pendingSubmissions = projects.filter((p: any) =>
    ["prototype", "data_sync"].includes(p.status)
  );

  // Calculate total drawings assigned
  const totalDrawings = Object.values(metricsData.projectDrawingCounts).reduce((a: any, b: any) => a + b, 0) as number;

  const kpis = [
    { label: "My Queue", value: projects.length, color: "text-blue-500", bg: "bg-blue-500/10", icon: PenTool },
    { label: "Total Drawings", value: totalDrawings, color: "text-indigo-500", bg: "bg-indigo-500/10", icon: Layers },
    { label: "Revisions", value: metricsData.activeRevisions.length, color: "text-amber-500", bg: "bg-amber-500/10", icon: AlertTriangle },
    { label: "Done", value: (assignedRes.data || []).filter((p: any) => p.status === "completed").length, color: "text-emerald-500", bg: "bg-emerald-500/10", icon: CheckCircle2 },
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-700">

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-2 border-b border-slate-200/60 dark:border-white/5">
        <div className="space-y-1">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500">CAD Terminal</p>
          <h1 className="text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-600 dark:from-white dark:to-slate-400">
            CAD <span className="text-blue-500">Workspace</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-lg font-medium">
            Welcome back, {firstName}.
          </p>
        </div>
        <div className="flex-shrink-0">
          {/* EOD button removed */}
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="glass-card border-white/10 p-5 flex flex-col gap-4">
              <div className={cn("w-10 h-10 rounded-2xl flex items-center justify-center", kpi.bg)}>
                <Icon className={cn("w-5 h-5", kpi.color)} />
              </div>
              <div>
                <p className="text-3xl font-black text-slate-900 dark:text-white">{kpi.value}</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">
                  {kpi.label}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-10 gap-8">

        {/* Left: Queue & Management (70%) */}
        <div className="xl:col-span-7 space-y-6">
          <Tabs defaultValue="drawings" className="space-y-6">
            <div className="border-b border-slate-200 dark:border-white/10 w-full overflow-x-auto custom-scrollbar pb-3">
              <TabsList className="bg-transparent border-none p-0 flex h-auto gap-8 w-full justify-start">
                <TabsTrigger
                  value="drawings"
                  className="px-1 py-2.5 rounded-none border-b-[3px] border-transparent text-sm font-semibold transition-all text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 data-[state=active]:border-blue-600 data-[state=active]:!text-blue-600 dark:data-[state=active]:!text-blue-400 flex items-center gap-2 data-[state=active]:shadow-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent"
                >
                  Assigned Drawings & Submissions
                </TabsTrigger>

                <TabsTrigger
                  value="revisions"
                  className="px-1 py-2.5 rounded-none border-b-[3px] border-transparent text-sm font-semibold transition-all text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 data-[state=active]:border-amber-600 data-[state=active]:!text-amber-600 dark:data-[state=active]:!text-amber-400 flex items-center gap-2 data-[state=active]:shadow-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent"
                >
                  Revision Requests
                  {metricsData.activeRevisions.length > 0 && (
                    <span className="px-1.5 py-0.2 text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded">
                      {metricsData.activeRevisions.length}
                    </span>
                  )}
                </TabsTrigger>

                <TabsTrigger
                  value="approvals"
                  className="px-1 py-2.5 rounded-none border-b-[3px] border-transparent text-sm font-semibold transition-all text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 data-[state=active]:border-indigo-600 data-[state=active]:!text-indigo-600 dark:data-[state=active]:!text-indigo-400 flex items-center gap-2 data-[state=active]:shadow-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent"
                >
                  Drawing Approvals
                  {pendingSubmissions.length > 0 && (
                    <span className="px-1.5 py-0.2 text-[10px] font-bold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded">
                      {pendingSubmissions.length}
                    </span>
                  )}
                </TabsTrigger>

                <TabsTrigger
                  value="productivity"
                  className="px-1 py-2.5 rounded-none border-b-[3px] border-transparent text-sm font-semibold transition-all text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 data-[state=active]:border-emerald-600 data-[state=active]:!text-emerald-600 dark:data-[state=active]:!text-emerald-400 flex items-center gap-2 data-[state=active]:shadow-none bg-transparent hover:bg-transparent data-[state=active]:bg-transparent"
                >
                  Productivity Metrics
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="drawings" className="mt-0 space-y-8">
              {/* My Assigned Queue & Approval Status */}
              <div className="space-y-4">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-blue-500" />
                    <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Active Assigned Projects</h2>
                  </div>
                </div>
                <div className="space-y-2">
                  {projects.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 border border-dashed border-white/10 rounded-2xl gap-3 text-center">
                      <div className="w-12 h-12 rounded-2xl bg-blue-500/5 flex items-center justify-center">
                        <PenTool className="w-6 h-6 text-blue-500/30" />
                      </div>
                      <p className="text-sm font-bold text-slate-500">No active CAD tasks</p>
                      <p className="text-xs text-slate-600">Pick up a project from the unassigned pool to begin.</p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                      {projects.map((p: any) => {
                        const count = metricsData.projectDrawingCounts[p.id] || 0;
                        return (
                          <PendingProjectListCard
                            key={p.id}
                            project={p}
                            showAccept={false}
                            extraBadge={
                              <div className="bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold px-3 py-1 rounded-full flex items-center gap-1.5">
                                <Layers className="w-3.5 h-3.5" />
                                {count} Drawing{count !== 1 ? 's' : ''} Uploaded
                              </div>
                            }
                          />
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* Unassigned Pool */}
              {/* {unassignedProjects.length > 0 && (
                <div className="space-y-4 pt-4 border-t border-slate-200/60 dark:border-white/5">
                  <div className="flex items-center gap-2 px-1">
                    <ListPlus className="w-4 h-4 text-indigo-500" />
                    <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Unassigned Projects Pool</h2>
                    <span className="px-2 py-0.5 rounded-full bg-indigo-500/10 text-[10px] font-bold text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                      {unassignedProjects.length} Available
                    </span>
                  </div>
                  <div className="space-y-2 max-h-[250px] overflow-y-auto pr-2 custom-scrollbar">
                    {unassignedProjects.map((p: any) => (
                      <PendingProjectListCard key={p.id} project={p} showAccept={true} />
                    ))}
                  </div>
                </div>
              )} */}
            </TabsContent>

            <TabsContent value="revisions" className="mt-0">
              {metricsData.activeRevisions.length === 0 ? (
                <EmptyState message="No active revision requests at this time." icon={CheckCircle} />
              ) : (
                <div className="space-y-3">
                  {metricsData.activeRevisions.map((rev: any) => (
                    <div key={rev.id} className="glass-card p-4 flex items-center justify-between border-amber-500/20 bg-amber-500/5 hover:bg-amber-500/10 transition-colors">
                      <div>
                        <h4 className="text-sm font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4" />
                          Revision Required
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{rev.title}</p>
                      </div>
                      <Link href={`/projects/${rev.project_id}?tab=issues`} className="text-xs font-bold text-white bg-amber-500 hover:bg-amber-600 px-4 py-2 rounded-lg transition-colors shadow-sm">
                        View Details
                      </Link>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="approvals" className="mt-0">
              {pendingSubmissions.length === 0 ? (
                <EmptyState message="No pending drawing approvals at this time." icon={CheckCircle} />
              ) : (
                <div className="space-y-3">
                  {pendingSubmissions.map((p: any) => {
                    const submittedAt = p.updated_at ? new Date(p.updated_at) : new Date();
                    const hoursSince = Math.max(0, differenceInHours(new Date(), submittedAt));
                    const isOverdue = hoursSince > 24;
                    const isPrototype = p.status === 'prototype';

                    return (
                      <PendingProjectListCard
                        key={p.id}
                        project={p}
                        showAccept={false}
                        hideDefaultBadge={true}
                        extraBadge={
                          <div className="flex flex-col items-end gap-1 text-right">
                            <div className="flex items-center gap-2">
                              <span className={cn(
                                "text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md",
                                isPrototype
                                  ? "bg-purple-500/10 text-purple-600 dark:text-purple-400"
                                  : "bg-blue-500/10 text-blue-600 dark:text-blue-400"
                              )}>
                                {isPrototype ? "Prototype" : "Final"}
                              </span>
                              <div className={cn(
                                "text-[10px] font-bold px-2 py-0.5 rounded-md border",
                                isOverdue
                                  ? "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20"
                                  : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20"
                              )}>
                                {isOverdue ? `🔴 Overdue (${hoursSince - 24}h)` : "🟢 On Time"}
                              </div>
                            </div>
                            <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400">
                              Submitted {formatDistanceToNow(submittedAt, { addSuffix: true })}
                            </span>
                          </div>
                        }
                      />
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="productivity" className="mt-0">
              <div className="glass-card p-6 border-emerald-500/20">
                <div className="flex items-center gap-2 mb-6">
                  <TrendingUp className="w-5 h-5 text-emerald-500" />
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">Weekly Productivity Metrics</h2>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-white/5 flex flex-col items-center justify-center text-center">
                    <Clock className="w-8 h-8 text-indigo-500 mb-3" />
                    <p className="text-4xl font-black text-slate-900 dark:text-white mb-1">
                      {metricsData.productivity.weeklyHours}
                    </p>
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Hours Logged</p>
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-2xl border border-slate-100 dark:border-white/5 flex flex-col items-center justify-center text-center">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500 mb-3" />
                    <p className="text-4xl font-black text-slate-900 dark:text-white mb-1">
                      {metricsData.productivity.weeklyTasksCompleted}
                    </p>
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Tasks Completed</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right: Action Panel (30%) */}
        <div className="xl:col-span-3 space-y-6">
          <DashboardNotificationCenter />

          <div className="glass-card border-blue-500/15 p-6 space-y-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-black text-slate-900 dark:text-white">Action Required</h3>
            </div>
            {pendingSubmissions.length === 0 ? (
              <div className="flex items-center gap-2 py-8 justify-center">
                <CheckCircle2 className="w-5 h-5 text-emerald-500/30" />
                <p className="text-xs text-slate-500 font-bold">All clear</p>
              </div>
            ) : (
              <div className="space-y-2">
                {pendingSubmissions.map((p: any) => (
                  <Link
                    key={p.id}
                    href={`/projects/${p.id}`}
                    className="block p-3 rounded-xl bg-amber-500/5 border border-amber-500/15 hover:border-amber-500/30 transition-all"
                  >
                    <p className="text-xs font-black text-slate-900 dark:text-white">{p.name}</p>
                    <p className="text-[10px] text-amber-500 mt-0.5 flex items-center gap-1">
                      <Upload className="w-2.5 h-2.5" />
                      {p.status === "data_sync" ? "Survey validation pending" : "CAD revision pending"}
                    </p>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* SOPs */}
      {/* <section className="space-y-4">
        <div className="flex items-center gap-2 px-1">
          <FileText className="w-4 h-4 text-blue-500" />
          <h2 className="text-lg font-bold text-slate-700 dark:text-gray-200">Departmental Protocols</h2>
        </div>
        <SOPList sops={sops} isAdmin={false} currentRole="cad" />
      </section> */}
    </div>
  );
}
